<?php  
session_start();
?>