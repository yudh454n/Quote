<style type="text/css">.btn:not(.btn-block) { margin-bottom:10px; }</style>

<div class="row">
<div class="col-md-4">	
<a href="?module=sgbquote" class="btn btn-primary btn-lg col-md-12" role="button"><span class="icon icon-star"></span> <br/>SGB Quote</a>
</div>
<div class="col-md-4">	
<a href="/" class="btn btn-warning btn-lg col-md-12" role="button"><span class="icon icon-star"></span> <br/>Next Soon</a>
</div>
<div class="col-md-4">	
<a href="/" class="btn btn-danger btn-lg col-md-12" role="button"><span class="icon icon-star"></span> <br/>Next Soon</a>
</div>
</div>